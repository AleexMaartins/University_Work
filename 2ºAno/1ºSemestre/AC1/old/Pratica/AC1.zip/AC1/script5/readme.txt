ex4 não está feito, é só mudar a forma de implementeção no ex3.
ex5 não tem a impressão dos dados do array, é só meter o código do ex2.