# Aula01 - Notes

to do
