package lab01;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class WSSolver {
    static int size = 0;
    static char[][] sopa; //sopa de letras original.
    static char[][] sopa2; //sopa preenchida com as palavras e pontos.

    static ArrayList<String> wordList = new ArrayList<String>();
    static ArrayList<String> prints = new ArrayList<String>(); // armazena os prints

    public static void main(String[] args) throws IOException{

        if (args.length != 1) {
            System.err.println("Invalid file name");
            System.exit(0);
        }

        boolean hasData = readData(args[0]);
        if (!hasData) {
            System.err.println("Invalid data format");
            System.exit(0);
        }
        
        System.out.printf("%-15s %6s %8s %14s\n", "Word", "Length", "Start", "Direction");

        // procurar as palavras na sopa
        for (String word: wordList) {
            if(!findWord(word)){
                System.out.printf("%s - Word Not Found\n", word);
                return;
            }
        }
        
        // dar print ao resultado das palavras
        for (String print: prints){
            System.out.print(print);
        }

        System.out.println();

        // print da sopa com os '.'
        for (int i = 0; i < size; i++){
            for (int j = 0; j < size; j++){
                System.out.printf("%c " ,sopa2[i][j]);
            }
            System.out.println();
        }
    }

    public static boolean findWord(String word){

        // percorrer a sopa
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
    
                //primeiro verificar se a letra corresponde à primeira letra da palavra
                if (sopa[i][j] != Character.toUpperCase(word.charAt(0))){
                    continue;
                }
    
                // Array com as direções possíveis
                int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, -1}, {-1, 1}, {1, -1}, {1, 1}};
    
                // Loop pelas direções
                for (int[] dir : directions) {
                    int dy = dir[0];
                    int dx = dir[1];
                    int y = i;
                    int x = j;
                    int y_ = i;
                    int x_ = j;

                    boolean found = true;

                    for (int k = 1; k < word.length(); k++) {
                        x += dx;
                        y += dy;
                        if (y < 0 || y >= size || x < 0 || x >= size || sopa[y][x] != word.toUpperCase().charAt(k)) {
                            found = false;
                            break;
                        }
                    }

                    if (found) {
                        for (int k = 0; k < word.length(); k++){
                            sopa2[y_][x_] = word.charAt(k);
                            y_ += dy;
                            x_ += dx;
                        }
                        prints.add(String.format("%-15s %6d %6d,%-6d %9s\n", word, word.length(), i + 1, j + 1, getDirectionName(dy, dx)));
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    private static String getDirectionName(int dy, int dx) {
        if (dy == -1 && dx == 0) return "Up";
        if (dy == 1 && dx == 0) return "Down";
        if (dy == 0 && dx == -1) return "Left";
        if (dy == 0 && dx == 1) return "Right";
        if (dy == -1 && dx == -1) return "UpLeft";
        if (dy == -1 && dx == 1) return "UpRight";
        if (dy == 1 && dx == -1) return "DownLeft";
        if (dy == 1 && dx == 1) return "DownRight";
        return "";
    }

    public static boolean readData(String fileName) throws IOException{
        File file;
        Scanner sc;
        try{
            file = new File(fileName);
            sc = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.print("Invalid filename.");
            return false;
        }

        String word = sc.nextLine();
        size = word.length();

        if(size>40){
            sc.close();
            System.out.println("Invalid size.");
            return false;
        }

        sopa = new char[size][size];
        sopa2 = new char[size][size];

        for (int i=0; i<size; i++){
            if(Character.isUpperCase(word.charAt(i))){
                sopa[0][i] = word.charAt(i);
            }else{
                sc.close();
                System.out.println("Letter is not uppercase!");
                return false;
            }
        }

        for (int i=1; i<size; i++){
            word = sc.nextLine();
            if(word.length() != size){
                sc.close();
                System.out.println("Not all lines have the same length.");
                return false;
            }
            for (int j=0; j<size; j++){
                if(Character.isUpperCase(word.charAt(j))){
                    sopa[i][j] = word.charAt(j);
                }
                else{
                    sc.close();
                    System.out.println("Letter is not uppercase!");
                    return false;
                }
            }
        }

        Pattern onlyUppLetters = Pattern.compile("^[A-Z]*$");
        Pattern onlyLetters = Pattern.compile("^[A-Za-z]*$");

        //separar as palavras e verificar se têm pelo menos uma letra minúscula
        while(sc.hasNextLine()){
            String line = sc.nextLine();
            for (String s: line.split("\\s+|\\;|\\,+")){
                if (onlyUppLetters.matcher(s).matches()) {
                    System.out.println("All letters of word is uppercase");
                    sc.close();
                    return false;
                }

                if (!onlyLetters.matcher(s).matches()) {
                    System.out.println("Word has non-letter characters");
                    sc.close();
                    return false;
                }

                if (wordList.contains(s)){
                    sc.close();
                    System.out.println("Two words can't be equal");
                    return false;
                }

                wordList.add(s);
            
            }
        }

        sc.close();
        
        //preencher a sopa2 com pontos
        for (int i=0; i<size; i++){
            for (int j=0; j<size; j++){
                sopa2[i][j] = '.';
            }
        }

        return true;
    }

}
