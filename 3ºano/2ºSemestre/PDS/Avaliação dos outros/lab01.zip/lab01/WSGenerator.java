package lab01;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class WSGenerator {
    
    static char[][] sopa;       //sopa de letras original

    static ArrayList<String> wordList = new ArrayList<String>();      
    static ArrayList<String> prints = new ArrayList<String>(); // armazena os prints

    public static void main(String[] args) throws Exception {

        String inputFile = "", outputFile = "";
        int size = 0;
        String possibleLetters = "ABCDEFGHIJKLKMNOPQRSTUVWXYZ";

        boolean isValidArgumentsSize = (args.length == 4 || args.length == 6);
        if (isValidArgumentsSize) {
            for (int i=0; i<args.length; i++) {
                if (args[i].equals("-i"))       // for input file
                    inputFile = args[i+1];      
                if (args[i].equals("-o"))       // for output file
                    outputFile = args[i+1];
                if (args[i].equals("-s")){       // for size of the soup
                    size = Integer.parseInt(args[i+1]);
                    if (size > 40) {
                        System.out.println("Invalid size");
                        System.exit(0);
                    }
                }
            }
        } else {
            System.out.println("Invalid command line arguments");
            System.exit(0);
        }

        boolean hasData = readData(inputFile);
        if (!hasData) {
            System.out.println("Invalid data format");
            System.exit(0);
        }

        // preenchimento da sopa com pontos
        sopa = new char[size][size];
        for (int i=0; i<size; i++){
            for(int j=0; j<size; j++)
                sopa[i][j] = '.';
        }

        /* Insert words */
        for (String word : wordList){
            insertWord(word, size);
        }

        /* Complete sopa */
        for (int i=0; i<size; i++){
            for(int j=0; j<size; j++) {
                if (sopa[i][j] == '.')
                    sopa[i][j] = possibleLetters.charAt( (int) (Math.random() * possibleLetters.length()));
            }
        }

        if (outputFile.length() > 0) //if there is -o
            writeOutputFile(outputFile, size);
        else {
            /* Print sopa */
            for (int i=0; i<size; i++){
                for(int j=0; j<size; j++)
                    System.out.printf("%c", sopa[i][j]);
                System.out.println();
            }
            for (String line : prints)
                System.out.println(line);
        }
    }

    public static boolean readData(String fileName) throws IOException {
        File file = new File(fileName);
        Scanner sc = new Scanner(file);

        String line;
        Pattern onlyUppLetters = Pattern.compile("^[A-Z]*$");
        Pattern onlyLetters = Pattern.compile("^[A-Za-z]*$");

        while (sc.hasNextLine()){
            line = sc.nextLine();
            prints.add(line);       //store the lines as they are to print them after the soup

            for (String s: line.split("\\s+|\\;|\\,+")){
                
                if (onlyUppLetters.matcher(s).matches()) {
                    System.out.println("All letters of word is uppercase");
                    sc.close();
                    return false;
                }

                if (!onlyLetters.matcher(s).matches()) {
                    System.out.println("Word has non-letter characters");
                    sc.close();
                    return false;
                }

                wordList.add(s);
            }
        }

        sc.close();
        return true;
    }

    public static void insertWord(String word, int size) {
        int[] x = {1, -1, 0, 0, 1, -1, 1, -1};
        int[] y = {0, 0, -1, 1, -1, -1, 1, 1};

        boolean validLimits;
        boolean wordIsNotOverlapped; 

        word = word.toUpperCase();
    
        do {
            int rand_x = (int) (Math.random() * size);
            int rand_y = (int) (Math.random() * size);
            int rand_dir = (int) (Math.random() * 8);
            validLimits = true;
            wordIsNotOverlapped = true;
    
            for (int i = 0; i < word.length(); i++) {
                int next_x = rand_x + x[rand_dir] * i;
                int next_y = rand_y + y[rand_dir] * i;
    
                if (next_x < 0 || next_x >= size || next_y < 0 || next_y >= size) {
                    validLimits = false;
                    break;
                }
    
                if (sopa[next_y][next_x] != '.' && sopa[next_y][next_x] != word.charAt(i)) {
                    wordIsNotOverlapped = false;
                    break;
                }
            }
    
            if (validLimits && wordIsNotOverlapped) {
                for (int i = 0; i < word.length(); i++) {
                    int next_x = rand_x + x[rand_dir] * i;
                    int next_y = rand_y + y[rand_dir] * i;
                    sopa[next_y][next_x] = word.charAt(i);
                }
            }
        } while (!validLimits || !wordIsNotOverlapped);
    }

    public static void writeOutputFile(String outputFile, int size) throws IOException {
        FileWriter fileWriter = new FileWriter(outputFile);
        PrintWriter printWriter = new PrintWriter(fileWriter);

        for (int i=0; i<size; i++){
            for(int j=0; j<size; j++)
               printWriter.printf("%c",  sopa[i][j]);
            printWriter.printf("\n");
        } 
        
        for (String line : prints)
            printWriter.println(line);

        printWriter.close();
    }
}
