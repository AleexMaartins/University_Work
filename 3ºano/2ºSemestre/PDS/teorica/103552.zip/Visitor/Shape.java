packages Visitor;
interface Shape {
    void accept(Visitor visitor);
}
