package State;

public interface StateInterface{
    public State getState();
    public void pull();
}
