package State;

public enum State {
    LOW, MEDIUM, HIGH, OFF
}
