package Strategy;

interface Strategy {
    int execute(int a, int b);
}
