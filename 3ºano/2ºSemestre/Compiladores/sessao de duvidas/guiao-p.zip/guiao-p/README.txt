Use ./run.jar or antlr4-jar-run to execute jar file. For example (inside ex2 directory):

./run-jar p1.txt

or:

java -jar FracLangMain.jar p1.txt

