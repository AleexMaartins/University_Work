public interface ShippingCostCalculator {
    double calculateShippingCost(Package pkg);
}
