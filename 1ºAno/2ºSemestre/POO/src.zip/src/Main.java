public class Main {
    public static void main(String[] args) {
        PackageManager pkg = new PackageManager();
        pkg.readPackagesFile("src/encomendas.txt");
        pkg.printAllPackageInfo();
        pkg.removePackage(22);
        pkg.printAllPackageInfo();
    }
}