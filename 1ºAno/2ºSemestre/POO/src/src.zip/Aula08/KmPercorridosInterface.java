package Aula08;

interface KmPercorridosInterface {
    public void trajeto(int quilometros);

    public int ultimoTrajeto();

    public int distanciaTotal();

}
