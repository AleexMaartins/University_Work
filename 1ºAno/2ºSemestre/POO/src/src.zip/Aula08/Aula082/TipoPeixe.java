package Aula082;

public enum TipoPeixe {
    CONGELADO,
    FRESCO
}