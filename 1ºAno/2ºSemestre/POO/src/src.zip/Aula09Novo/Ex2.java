public class Ex2 {
    
}
