package Ex2;

public enum Ex2TipoPeixe {
    CONGELADO,
    FRESCO
}