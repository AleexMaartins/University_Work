package Ex2;

public enum Ex2VariedadeCarne {
    VACA,
    PORCO,
    PERU,
    FRANGO,
    OUTRA
}