package Aula12;

public class Ex1 {

}
