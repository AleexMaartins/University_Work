package Aula08Novo;

public interface Ex1bVeiculoEletrico {
    int autonomia();
    void carregar(int percentagem);
}
