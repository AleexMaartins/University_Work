package ExamePratico;

public enum TipoComida {
    CHURRASQUEIRA, ITALIANO, MARISQUEIRA, VEGETARIANO
}
