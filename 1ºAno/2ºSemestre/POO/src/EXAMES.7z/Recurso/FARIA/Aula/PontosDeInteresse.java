package ExamePratico;
import java.util.*;

;public interface PontosDeInteresse {
    Collection<String> Locais();
}
